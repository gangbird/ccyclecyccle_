from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('Main/main.html')

@app.route('/people_selection')
def people_selection():
    return render_template('Track/Selection/people_selection.html')

@app.route('/management')
def management():
    return render_template('Track/Management/track_management.html')

@app.route('/group_selection')
def kategorie_selection():
    people = request.args.get('people')
    return render_template('Track/Selection/group_selection.html', people=people)

@app.route('/tempo_selection')
def tempo_selection():
    category = request.args.get('category')
    return render_template('Track/Selection/tempo_selection.html', category=category)

@app.route('/date_selection')
def date_selection():
    return render_template('Track/Selection/date_selection.html')

@app.route('/playtime_selection')
def time_selection():
    return render_template('Track/Selection/playtime_selection.html')

@app.route('/when_selection')
def when_selection():
    time = request.args.get('time')
    return render_template('Track/Selection/when_selection.html', time=time)

@app.route('/menu_prefer_selection')
def menu_prefer_selection():
    return render_template('Track/Selection/menu_prefer_selection.html')


@app.route('/restaurant_selection')
def restaurant_selection():
    return render_template('Track/Selection/restaurant_selection.html')

if __name__ == '__main__':
    app.run('0.0.0.0', port=5000, debug=True)


